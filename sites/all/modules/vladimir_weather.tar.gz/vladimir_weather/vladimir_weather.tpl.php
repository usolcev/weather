<div id='city_forme'><?php print $city_form; ?></div>
<div id='temperature'><?php print $temperature; ?> </div>